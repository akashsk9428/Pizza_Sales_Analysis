-- Identify the most common pizza size ordered.

SELECT 
    quantity, COUNT(order_details_id)
FROM
    order_details
GROUP BY quantity
LIMIT 1;

SELECT 
    p.size, COUNT(od.order_details_id) AS quantity
FROM
    pizzas p
        JOIN
    order_details od USING (pizza_id)
GROUP BY p.size
ORDER BY quantity desc
LIMIT 1;