-- 9) Group the orders by date and calculate the average number of pizzas ordered per day.

select round(avg(quantity),0) from
(SELECT 
    o.order_date, SUM(od.quantity) AS quantity
FROM
    orders o
        JOIN
    order_details od USING (order_id)
GROUP BY o.order_date) as order_quantity;