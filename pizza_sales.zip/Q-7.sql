-- Determine the distribution of orders by hour of the day.
SELECT 
    HOUR(order_time) as hour, COUNT(order_id) quantity
FROM
    orders o
GROUP BY HOUR(order_time)