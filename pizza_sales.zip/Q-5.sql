-- List the top 5 most ordered pizza types along with their quantities.

SELECT 
    pt.name, sum(od.quantity) as quantity
FROM
    pizzas p
        JOIN
    pizza_types pt USING (pizza_type_id)
        JOIN
    order_details od USING (pizza_id)
GROUP BY pt.name
ORDER BY quantity DESC
LIMIT 5;