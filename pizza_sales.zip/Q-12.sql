-- 12) Analyze the cumulative revenue generated over time.
select order_date,
sum(revenue) over(order by order_date) as cum_rev
from
(SELECT 
    o.order_date, SUM(od.quantity * p.price) AS revenue
FROM
    orders o
        JOIN
    order_details od USING (order_id)
        JOIN
    pizzas p USING (pizza_id)
GROUP BY o.order_date) as sales