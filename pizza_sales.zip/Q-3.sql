-- Identify the highest-priced pizza.
SELECT 
    pt.name, p.price
FROM
    pizza_types pt
        JOIN
    pizzas p USING (pizza_type_id)
ORDER BY price DESC
LIMIT 1;