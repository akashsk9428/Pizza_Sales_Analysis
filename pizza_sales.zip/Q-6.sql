-- Join the necessary tables to find the total quantity of each pizza category ordered.
SELECT 
    pt.category, sum(od.quantity) as quantity
FROM
    pizzas p
        JOIN
    pizza_types pt USING (pizza_type_id)
        JOIN
    order_details od USING (pizza_id)
GROUP BY pt.category
ORDER BY quantity DESC
LIMIT 5;