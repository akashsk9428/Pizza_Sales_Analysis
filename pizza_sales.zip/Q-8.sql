-- 8) find the category wise orders

SELECT 
    pt.category, COUNT(o.order_id) AS orders
FROM
    order_details od
        JOIN
    orders o USING (order_id)
        JOIN
    pizzas p USING (pizza_id)
        JOIN
    pizza_types pt USING (pizza_type_id)
GROUP BY category
