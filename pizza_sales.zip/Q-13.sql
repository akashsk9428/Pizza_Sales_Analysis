-- Determine the top 3 most ordered pizza types
-- based on revenue for each pizza category.
select category,name, revenue,rk
from
(select category,name,revenue,
rank() over(partition by category order by revenue desc) as rk
from
(select pt.category,pt.name,
sum((od.quantity)*p.price) as revenue
from  pizza_types pt 
join pizzas p 
using (pizza_type_id)
join order_details od
using(pizza_id)
group by pt.category,pt.name) as a) as b
where rk <=3

