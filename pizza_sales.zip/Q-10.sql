-- Determine the top 3 most ordered pizza types based on revenue.
SELECT 
    p.pizza_id AS pizza_types,
    round(sum(od.quantity * p.price),0) AS revenue,
    count(quantity) AS orders
FROM
    pizzas p
        JOIN
    pizza_types pt USING (pizza_type_id)
        JOIN
    order_details od USING (pizza_id)
GROUP BY p.pizza_id
ORDER BY revenue DESC
LIMIT 3;
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
SELECT 
   pt.name,sum(od.quantity*p.price) as revenue,sum(quantity) as quantity
FROM
    pizzas p
        JOIN
    pizza_types pt USING (pizza_type_id)
        JOIN
    order_details od USING (pizza_id)
GROUP BY pt.name
ORDER BY revenue DESC
LIMIT 3;



