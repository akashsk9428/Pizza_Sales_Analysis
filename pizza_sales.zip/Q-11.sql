-- Calculate the percentage contribution of each pizza type to total revenue.

SELECT 
    pt.category AS pizza_types,
	round((sum(od.quantity * p.price) / (select
    ROUND(SUM(od.quantity * p.price),
    2) as total_sales
FROM
    order_details od
        JOIN
    pizzas p on p.pizza_id = od.pizza_id))*100,2) as revenue
FROM
    pizzas p
        JOIN
    pizza_types pt USING (pizza_type_id)
        JOIN
    order_details od USING (pizza_id)
GROUP BY pt.category
ORDER BY revenue DESC